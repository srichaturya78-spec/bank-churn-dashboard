# Bank Customer Churn — Streamlit Dashboard

## Files in this folder
- `app.py` — the Streamlit dashboard (4 modules: Risk Calculator, Probability Distribution, Feature Importance, What-If Simulator)
- `train_and_save.py` — trains the Random Forest model on `European_Bank.csv` and saves `model_artifact.pkl`
- `model_artifact.pkl` — pre-trained model + supporting data (already generated for you)
- `requirements.txt` — Python packages needed to run the app

## How to run it

1. Install dependencies (one time):
   ```
   pip install -r requirements.txt
   ```

2. Launch the dashboard:
   ```
   streamlit run app.py
   ```

3. Your browser will open automatically at `http://localhost:8501`.

## If you want to retrain on new data

Replace `European_Bank.csv` with your updated file (same column structure), then re-run:
```
python train_and_save.py
streamlit run app.py
```

## Dashboard modules

| Module | What it does |
|---|---|
| **Overview** | Headline stats and churn-rate breakdowns by country and product count |
| **Churn Risk Calculator** | Enter one customer's profile → get an instant churn probability and risk band |
| **Probability Distribution** | Histogram of churn risk across the whole customer base, plus risk-band segmentation |
| **Feature Importance** | Ranked chart of which factors drive the model's predictions, with plain-English interpretation |
| **What-If Simulator** | Compare a customer's risk *before* and *after* a simulated retention action (e.g. re-engaging them or adjusting product count) |
